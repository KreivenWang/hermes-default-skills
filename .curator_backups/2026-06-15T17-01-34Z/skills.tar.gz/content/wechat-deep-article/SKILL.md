---
name: wechat-deep-article
description: "公众号深度分析文章工作流：从每日简报选一个安全话题，写深度分析文章，生成图文并推送到草稿箱。"
version: 1.3.0
author: Hermes Agent
tags: [wechat, article, analysis, deep-dive, content, publishing]
---

# 公众号深度分析文章工作流

角色：科技行业分析师。每天简报完成后，选一个安全话题写深度分析文章，以 JSON 格式组织内容，用 `scripts/publish_article.py` 推送草稿箱。

## 安全红线

以下话题**不得选为公众号主题**，也不得在正文中提及：

- 🔴 **中国政治/政府**：不涉及国内政策、领导人、行政干预、涉外事件
- 🔴 **军事冲突**：不涉及伊朗、俄乌、中东等战争/军事行动
- 🔴 **外媒涉华负面**：不引用外媒对中国政府/企业的批评报道
- 🔴 **美国内政**：不涉及特朗普、大选、国会、党派斗争
- 🔴 **敏感国际关系**：不涉及朝鲜、台湾、南海、新疆
- 🔴 **社会事件**：不涉及中国境内抗议、事故、灾难

## ✅ 安全话题池

| 类型 | 示例 | 说明 |
|------|------|------|
| AI 公司动态 | Mistral 融资、OpenAI 产品、Google AI | 技术+商业，完全安全 |
| 科技趋势 | 模型进展、开源生态、AI 应用落地 | 纯技术分析 |
| 学术突破 | 论文发表、科研成果（国内国外都可） | 安全，尤其是中国成果 |
| 商业/并购 | 收购、IPO、融资 | 纯商业事件 |
| 市场数据 | 股价、油价、通胀数据 | 数据中性 |
| 产品评测 | 新模型、新应用、新硬件 | 用户体验向 |

## 工作流

### Step 1 — 等简报完成
确保当日 `references/YYYY-MM-DD-audit.md` 和 `links.md` 已生成。

### Step 2 — 选话题
从简报中选 1 条安全话题。优先级：
1. AI 类（最安全，读者爱看）
2. 科技商业类
3. 中国科研成就类

**跨天去重**：检查 `references/YYYY-MM-DD-topics.md`（前一天的简报话题），排除上一期已有深度文的核心话题。用户对「前一天消息今天又深挖」敏感。

### 格式化约定

输出作者为**「简报」**（不要带 "Hermes" 前缀）。
文章正文**不加任何顶部标题栏/日期栏**。

支持三色高亮语法：
| 语法 | 颜色 | 用途 |
|------|------|------|
| `**蓝色**` | 蓝色 | 核心数字/概念 |
| `==橙色==` | 橙色 | 强调差异 |
| `~~紫色~~` | 紫色 | 特殊术语 |

HTML 存档自动保存在 `scripts/.article_output/`，仅供回溯。

### Step 3 — 深入调研
围绕选定话题搜索至少 3-5 个来源，收集背景信息、最新数据、行业影响、图片素材。

**图片采集顺序**：
1. 从新闻原文提取 `og:image`
2. 如 curl 超时 → 用 Unsplash `?w=800` 限制大小
3. `curl -sI` 验证 URL 返回 HTTP 200 再用

### Step 4 — 撰写 JSON 文章

```json
{
  "date": "2026-06-15",
  "title": "有信息量的标题，不用过于吸睛但得说清楚核心论点",
  "author": "简报",
  "digest": "100字以内的摘要",
  "source_declaration": "本文素材来源：TechCrunch、CNBC",
  "sections": [
    {"type": "text", "content": "正文段落，支持**三色高亮**"},
    {"type": "heading", "content": "小标题"},
    {"type": "comparison", "content": "❌ ...\n\n✅ ..."},
    {"type": "tip", "content": "要点总结"}
  ],
  "image_sources": [
    "https://...真实可访问的图片URL"
  ],
  "source_links": [
    {"source": "TechCrunch", "url": "https://..."}
  ]
}
```

### 排版类型一览

| type | 效果 | 适用场景 |
|------|------|---------|
| `text` | 标准段落，三色高亮 | 正文 |
| `heading` | 左侧蓝条 + emoji | 章节标题 |
| `subheading` | 蓝色圆角药丸 | 小节 |
| `comparison` | ❌红色 / ✅绿色卡片 | 对比 |
| `tip` | 💡 绿色卡片 | 总结 |
| `warning` | ⚠️ 黄色卡片 | 注意 |
| `quote` | 灰色斜体引用 | 引用原文 |
| `list` | 圆点列表 | 要点 |
| `quiz` | 紫色渐变卡片 + 🔒 | 小测试 |
| `image` | 指定位置插配图 | 图片定位 |
| `divider` | ✦ ✦ ✦ 装饰线 | 分段 |
| `collocation` | 蓝色短语卡片 + 释义 + 例句 | 搭配展示（用于英语笔记类） |

### Step 5 — 发布

```bash
rm -rf scripts/../.img_cache/
python3 scripts/publish_article.py scripts/.article_YYYY-MM-DD_topic.json
```

发布脚本自动完成：
1. 读取 JSON 文章
2. 用 Pillow 生成文字卡片封面图（深蓝渐变 + 大标题文字 + 顶部彩色装饰条）
3. 从 `image_sources` 下载配图并上传微信 CDN
4. 上传封面图到素材库获取 media_id
5. 生成 WeChat 兼容 HTML（全部 inline style）
6. 调用 draft/add 创建草稿
7. 保存本地 HTML 副本

**配图策略**：脚本**不再自动补充随机 Unsplash 配图**。`image_sources` 只包含 JSON 中指定的 URL + 自动生成的文字卡片封面。手动在 JSON 中填配图。

### Step 6 — 用户确认
提供素材来源平台 + event_date 供群发弹窗填写。

## 常见陷阱

1. **JSON 引号**：正文用「」替代 `"`，避免解析报错
2. **图片 URL 无效**：凭记忆写的 URL 大概率 404。先用 `curl -sI` 验证再写入 JSON。Unsplash 图加 `?w=800` 限制大小。
3. **40007 invalid media_id**：封面图上传失败。排查方法：看发布日志有没有「封面图 media_id: ...」行。
4. **摘要超长**：微信限 128 字符，`45004` 错误。控制在 100 字以内。
5. **同一天多次发布不清理缓存**：`.img_cache/` 残留旧图片可能尺寸异常，导致 `upload_material` 静默失败。**每次重新发布前 `rm -rf scripts/../.img_cache/`**。
6. **不选昨天头条做深度文**：用户反感「同一个消息又发一遍」。选 AI 类新消息。
7. **宣传语≠深度分析**：标题不要写成公众号爆款文风格（"震惊""必看"），保持客观。
