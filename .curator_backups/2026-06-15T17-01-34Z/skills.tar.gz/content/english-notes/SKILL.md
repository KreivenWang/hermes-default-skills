---
name: english-notes
description: "英语笔记公众号文章工作流：用户触发一个单词/词组/说法，查牛津+剑桥词典中英英英释义，分析职场和生活地道用法，生成带小测试的图文并推送草稿箱。"
version: 2.0.0
author: Hermes Agent
tags: [english, learning, notes, wechat, vocabulary]
---

# 英语笔记公众号文章工作流

角色：英语学习导师。用户触发一个单词/词组/说法后，查词典、分析用法、整理成图文并推送公众号草稿箱。

## 安全红线

- 不涉及中国政治、领导人、敏感国际关系
- 纯语言学习内容，安全

## 工作流

### Step 1 — 用户触发
用户给出一个单词/词组/用法主题。

### Step 2 — 词典调研
```bash
# Oxford（英英释义、音标、例句、搭配）
curl -sL "https://www.oxfordlearnersdictionaries.com/definition/english/{word}"
# Cambridge 中英（中文翻译、双语例句）
curl -sL "https://dictionary.cambridge.org/dictionary/english-chinese-simplified/{word}"
```

### Step 3 — 撰写标题
**格式**：`英语笔记｜钩子 · /音标/`

✅ 英语笔记｜别再只会说 I remember，impression 才是职场地道表达 · /ɪmˈpreʃn/
❌ 英语笔记 · impression · /ɪmˈpreʃn/

### Step 4 — 撰写 JSON 文章

```json
{
  "date": "2026-06-15",
  "event_date": "2026-06-15",
  "title": "英语笔记｜钩子标题 · /音标/",
  "author": "简报",
  "digest": "50字摘要",
  "source_declaration": "本文来源：Oxford Learner's Dictionaries、Cambridge Dictionary",
  "sections": [
    {"type": "text", "content": "引言"},
    {"type": "handwrite", "content": "English sentence\n===中文翻译"},
    {"type": "heading", "content": "英英释义"},
    {"type": "text", "content": "**加粗**蓝色 / ==双等号==橙色 / ~~双波浪~~紫色"},
    {"type": "comparison", "content": "❌ 中式\n\n✅ 地道"},
    {"type": "collocation", "content": "phrase\n「释义」\n· 例句\n\nphrase2\n「释义2」\n· 例句2"},
    {"type": "quiz", "content": "选择题\nA. ...\nB. ..."}
  ],
  "image_sources": [],
  "source_links": [
    {"source": "Oxford", "url": "https://..."}
  ]
}
```

### 支段类型一览（13种）

| type | 效果 | 用途 |
|------|------|------|
| `text` | 标准段落，支持三色高亮 | 正文 |
| `heading` | 左侧蓝条 + emoji 自动匹配 | 章节标题 |
| `subheading` | 蓝色圆角药丸 | 小节 |
| `comparison` | 红底❌ / 绿底✅ 卡片 | 中式 vs 地道 |
| `collocation` | 独立卡片，蓝短语+灰释义+例句 | 常见搭配 |
| `tip` | 💡 绿色提示卡片 | 总结 |
| `warning` | ⚠️ 黄色卡片 | 注意 |
| `quote` | 灰色斜体引用 | 错误例句 |
| `quiz` | 紫色渐变卡片 + 🔒 | 小测试 |
| `handwrite` | 手绘风卡片(暖纸+手写体) | 核心例句展示 |
| `image` | 插下一张配图 | 指定位置 |
| `divider` | ✦ ✦ ✦ 装饰线 | 分隔 |
| `list` | 圆点列表 | 罗列 |

### 三色高亮语法
- `**蓝色**` — 核心数字/概念
- `==橙色==` — 对比差异
- `~~紫色~~` — 易错点

### handwrite 卡片内容格式
```
英文句子（支持多行）
===中文翻译
```

### 配图策略
- `image_sources` 留空 `[]`（默认行为）
- 封面图：Pillow 自动生成文字卡片（大字核心词 + 音标），**始终作为微信封面图（thumb_id）** 上传
- handwrite 段：自动生成手绘风卡片（暖纸底色 + Noteworthy 手写体 + 中文翻译）
- **英语笔记不自动抓取原文 og:image**，所有配图由卡片生成提供，避免无关的词典 logo/插图
- 内容插图去掉了外层 `<div>` 包裹和 `box-shadow`，直接以 `<img>` 展示，无白框

### Step 5 — 发布
```bash
rm -rf scripts/../.img_cache/  # 清理缓存（每次发布前）
cd scripts/../
python3 scripts/publish_article.py scripts/.article_YYYY-MM-DD_topic.json
```

### Step 6 — 用户确认
提供素材来源平台 + event_date 供群发弹窗填写。

## 已知陷阱

1. **JSON 引号**：正文用「」替代英文 `"`，避免解析报错
2. **摘要超长**：微信限 128 字符，控制 60 字内
3. **缓存复用**：同一天多次发布需 `rm -rf scripts/../.img_cache/`，否则旧残留图片导致封面图 `40007`
4. **颜色别滥用**：全篇 3-4 处彩色高亮足够
5. **标题不要用 `·` 分隔**：文字卡片从 `｜` 后提取核心词，钩子内容放 `｜` 后、`·` 前
6. **小测试答案**：用 `quiz` 类型自动渲染，答案下期公布
