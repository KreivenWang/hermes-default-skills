#!/usr/bin/env python3
"""
公众号独立文章发布器 — 从文章 JSON 生成 WeChat 图文并推送到草稿箱。

用法:
  python3 scripts/publish_article.py scripts/.article_2026-06-13_mistral.json

文章 JSON 格式:
  {
    "date": "2026-06-13",
    "title": "文章标题",
    "author": "作者名",
    "digest": "摘要",
    "sections": [
      {"type": "heading", "content": "小标题"},
      {"type": "text", "content": "正文段落..."}
    ],
    "image_sources": ["url1", "url2"],
    "source_links": [{"source": "来源名", "url": "https://..."}]
  }

支持的 section types:
  text       — 标准段落，**关键词**蓝色高亮
  heading    — 标题（左侧蓝条 + emoji）
  subheading — 子标题（蓝色小药丸）
  comparison — ❌ ✅ 对比块
  list       — 列表
  tip        — 绿色提示卡片
  warning    — 黄色警告卡片
  quote      — 引用块
  quiz       — 小测试卡片（带🔒下期公布）
  image      — 指定位置插入配图
  divider    — 分割线
"""

import json
from datetime import datetime
import os
import re
import ssl
import sys
import urllib.request
from pathlib import Path

# ── 路径 ──────────────────────────────────────────────────────────
SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = SKILL_DIR / "scripts" / ".wechat_config.json"
OUTPUT_DIR = SKILL_DIR / "scripts" / ".article_output"

# ── WeChat API ────────────────────────────────────────────────────
WX_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token"
WX_UPLOAD_IMG_URL = "https://api.weixin.qq.com/cgi-bin/media/uploadimg"
WX_UPLOAD_MATERIAL_URL = "https://api.weixin.qq.com/cgi-bin/material/add_material"
WX_DRAFT_ADD_URL = "https://api.weixin.qq.com/cgi-bin/draft/add"

# ── 样式常量 ─────────────────────────────────────────────────────
PAGE_BG = "#f5f5f5"
ARTICLE_BG = "#ffffff"
TEXT_BODY = "#2c3e50"
TEXT_DESC = "#7f8c8d"
LINK_COLOR = "#1a73e8"
ACCENT = "#2563eb"
ACCENT_GREEN = "#16a34a"
ACCENT_ORANGE = "#d97706"
ACCENT_RED = "#dc2626"
ACCENT_PURPLE = "#7c3aed"
BORDER = "#e5e7eb"
HIGHLIGHT_BG = "#eff6ff"

# ── 配图推荐池（Unsplash photo IDs，自动按类目补充） ──────────────
UNSPLASH_POOLS = {
    "default": [
        "1485827404703-89b55fcc595e",
        "1535378917042-10a22c95931a",
    ],
    "英语笔记": [
        "1456401264171-8a27a5b0f6e6",
        "1455390582262-044cdead277a",
        "1491841573631-5e0a2f1d0b9c",
        "1503671458372-3cd8427d6d8c",
        "1499543541294-11e9b44a49ad",
        "1524995997946-a1c2e315a42f",
    ],
    "深度分析": [
        "1519389950473-47ba0277781c",
        "1486312338219-ce68d2c6f44d",
    ],
    "简报": [
        "1504711434969-e33886168c44",
        "1495020689067-958852a7765e",
    ],
}

def auto_supplement_images(article_data):
    """不再自动补充随机配图。只保留 JSON 中指定的图片 + 后续生成的文字卡片。"""
    return article_data


# ── 文字卡片图片生成 ────────────────────────────────────────────
try:
    from PIL import Image, ImageDraw, ImageFont
    _HAS_PIL = True
except ImportError:
    _HAS_PIL = False

def generate_title_card(text, subtitle="", output_path=None):
    """生成渐变背景 + 大标题的文字卡片图。返回路径或 None。"""
    if not _HAS_PIL:
        return None
    w, h = 800, 450
    img = Image.new('RGB', (w, h))
    draw = ImageDraw.Draw(img)
    # Gradient: deep navy to vibrant blue
    for y in range(h):
        ratio = y / h
        r = int(15 + ratio * 25)
        g = int(30 + ratio * 55)
        b = int(80 + ratio * 100)
        draw.line([(0, y), (w, y)], fill=(r, g, b))
    # Accent line at the top
    accent_h = 6
    for y in range(accent_h):
        ratio = y / accent_h
        r = int(60 + ratio * 100)
        g = int(130 - ratio * 30)
        b = int(220 - ratio * 20)
        draw.line([(0, y), (w, y)], fill=(r, g, b))
    # Font
    font = None
    for fp in ["/System/Library/Fonts/STHeiti Medium.ttc",
               "/System/Library/Fonts/PingFang.ttc",
               "/System/Library/Fonts/Helvetica.ttc"]:
        try:
            import os as _os
            if _os.path.exists(fp):
                font = ImageFont.truetype(fp, 56)
                break
        except Exception:
            continue
    if font is None:
        font = ImageFont.load_default()
    # Main text
    lines = text.split('\n')
    total_h = 0
    line_boxes = []
    for line in lines:
        b = draw.textbbox((0, 0), line, font=font)
        line_boxes.append((line, b))
        total_h += b[3] - b[1] + 8
    # Vertical position (shift up slightly to leave room for subtitle)
    start_y = (h - total_h) // 2 - 20
    cy = start_y
    for line, bbox in line_boxes:
        lw = bbox[2] - bbox[0]
        text_x = (w - lw) // 2
        draw.text((text_x, cy), line, fill='white', font=font)
        cy += bbox[3] - bbox[1] + 8
    # Subtitle
    if subtitle:
        sf = None
        try:
            sf = ImageFont.truetype("/System/Library/Fonts/STHeiti Medium.ttc", 20)
        except Exception:
            sf = ImageFont.load_default()
        if sf:
            sb = draw.textbbox((0, 0), subtitle, font=sf)
            sw = sb[2] - sb[0]
            sub_x = (w - sw) // 2
            sub_y = cy + 16
            # Draw a subtle background pill for subtitle
            pill_pad = 16
            draw.rounded_rectangle(
                [(sub_x - pill_pad, sub_y - 4), (sub_x + sw + pill_pad, sub_y + sb[3] - sb[1] + 4)],
                radius=12, fill=(255, 255, 255, 20)
            )
            draw.text((sub_x, sub_y), subtitle, fill='#93c5fd', font=sf)
    if output_path:
        img.save(output_path)
    return output_path


# ── 手写风例句卡片生成 ──────────────────────────────────────────
def generate_handwrite_card(text, subtitle="", index=0, cache_dir=None):
    """生成手绘风例句卡片图（暖纸背景+手写体+粗糙边框）。返回路径或 None。"""
    if not _HAS_PIL:
        return None
    if cache_dir is None:
        return None
    w, h = 700, 200
    bg = (250, 243, 224)
    bc = (220, 210, 190)
    tc = (80, 60, 40)
    sc = (140, 120, 100)

    img = Image.new('RGB', (w, h), bg)
    draw = ImageDraw.Draw(img)

    # Rough border (slightly offset for hand-drawn feel)
    for off in [0, 1, 2]:
        draw.rounded_rectangle([off, off, w-1-off, h-1-off],
                              radius=16, outline=bc, width=1)
    # Shadow
    for i in range(3):
        draw.rounded_rectangle([3+i, 3+i, w-1, h-1],
                              radius=16, outline=(0, 0, 0, 12), width=1)

    # Font: handwriting first
    font = None
    for fp in ['/System/Library/Fonts/Noteworthy.ttc',
               '/System/Library/Fonts/Supplemental/Bradley Hand Bold.ttf',
               '/System/Library/Fonts/STHeiti Medium.ttc']:
        try:
            if os.path.exists(fp):
                font = ImageFont.truetype(fp, 30)
                break
        except:
            continue
    if font is None:
        font = ImageFont.load_default()

    # Draw text
    lines = text.split('\n')
    line_h = 0
    for line in lines:
        b = draw.textbbox((0, 0), line, font=font)
        lw = b[2] - b[0]
        lh = b[3] - b[1]
        lx = (w - lw) // 2
        ly = (h - (len(lines) * (lh + 6))) // 2 + line_h
        draw.text((lx, ly), line, fill=tc, font=font)
        line_h += lh + 6

    # Subtitle (Chinese, below English)
    if subtitle:
        sf = None
        try:
            sf = ImageFont.truetype("/System/Library/Fonts/STHeiti Medium.ttc", 16)
        except:
            sf = ImageFont.load_default()
        if sf:
            sb = draw.textbbox((0, 0), subtitle, font=sf)
            sw = sb[2] - sb[0]
            sfy = ly + lh + 14
            draw.line([(50, sfy-2), (w-50, sfy-2)], fill=(215, 205, 185), width=1)
            draw.text(((w - sw) // 2, sfy), subtitle, fill=sc, font=sf)

    out = cache_dir / f"_handwrite_{index:02d}.png"
    img.save(str(out))
    return str(out)


# ── 从原文抓取配图 ──────────────────────────────────────────────
def fetch_og_images_from_sources(article_data, max_images=2):
    """从 source_links 中的 URL 提取 og:image。仅在 JSON 未指定配图时执行。"""
    existing = article_data.get("image_sources", [])
    # 如果 JSON 里已经指定了配图，不自动抓取
    if existing:
        return article_data
    new_images = []
    for link in article_data.get("source_links", []):
        if len(new_images) + len(existing) >= max_images + 2:
            break
        url = link.get("url", "")
        if not url:
            continue
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}, method="GET")
            resp = urllib.request.urlopen(req, timeout=8, context=ctx)
            html = resp.read().decode("utf-8", errors="ignore")
            import re as _re
            m = _re.search(r'<meta[^>]*property="og:image"[^>]*content="([^"]+)"', html)
            if not m:
                m = _re.search(r'<meta[^>]*content="([^"]+)"[^>]*property="og:image"', html)
            if m:
                img_url = m.group(1)
                if img_url not in existing:
                    new_images.append(img_url)
                    existing.add(img_url)
        except Exception:
            continue
    if new_images:
        article_data.setdefault("image_sources", []).extend(new_images)
    return article_data


def log(msg):
    print(f"  ✓ {msg}", file=sys.stderr)

def warn(msg):
    print(f"  ⚠ {msg}", file=sys.stderr)

def step(msg):
    print(f"\n  ► {msg}", file=sys.stderr)

def h(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

def _urlopen(url, data=None, timeout=15):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(
        url, data=data,
        headers={"User-Agent": "Mozilla/5.0 Chrome/120"}
    )
    return urllib.request.urlopen(req, timeout=timeout, context=ctx)

# ── WeChat API ────────────────────────────────────────────────────

def get_token(cfg):
    url = f"{WX_TOKEN_URL}?grant_type=client_credential&appid={cfg['appid']}&secret={cfg['app_secret']}"
    try:
        resp = _urlopen(url)
        data = json.loads(resp.read())
        if "access_token" in data:
            log(f"access_token 获取成功")
            return data["access_token"]
        warn(f"获取 token 失败: {data}")
    except Exception as e:
        warn(f"token 异常: {e}")
    return None

def upload_img(image_path, token):
    """上传正文图片到微信 CDN，返回 CDN URL。"""
    url = f"{WX_UPLOAD_IMG_URL}?access_token={token}"
    try:
        boundary = "----Boundary7MA4YWxkTrZu0gW"
        with open(image_path, "rb") as f:
            file_data = f.read()
        fname = os.path.basename(image_path)
        body_parts = [
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="media"; filename="{fname}"\r\n'.encode(),
            b"Content-Type: image/jpeg\r\n\r\n",
            file_data,
            f"\r\n--{boundary}--\r\n".encode(),
        ]
        body = b"".join(body_parts)
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, data=body, headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
        resp = urllib.request.urlopen(req, timeout=30, context=ctx)
        result = json.loads(resp.read())
        if "url" in result:
            return result["url"]
        warn(f"上传失败: {result}")
    except Exception as e:
        warn(f"上传异常: {e}")
    return None

def upload_material(image_path, token):
    """上传封面图到素材库，返回 media_id。"""
    url = f"{WX_UPLOAD_MATERIAL_URL}?access_token={token}&type=image"
    try:
        boundary = "----Boundary7MA4YWxkTrZu0gW"
        with open(image_path, "rb") as f:
            file_data = f.read()
        fname = os.path.basename(image_path)
        body_parts = [
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="media"; filename="{fname}"\r\n'.encode(),
            b"Content-Type: image/jpeg\r\n\r\n",
            file_data,
            f"\r\n--{boundary}--\r\n".encode(),
        ]
        body = b"".join(body_parts)
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, data=body, headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
        resp = urllib.request.urlopen(req, timeout=30, context=ctx)
        result = json.loads(resp.read())
        if "media_id" in result:
            return result["media_id"]
        warn(f"封面上传失败: {result}")
    except Exception as e:
        warn(f"封面上传异常: {e}")
    return None

def create_draft(title, html, author, digest, thumb_id, token):
    url = f"{WX_DRAFT_ADD_URL}?access_token={token}"
    body = {
        "articles": [{
            "title": title[:64],
            "author": author[:16],
            "digest": digest[:128],
            "content": html,
            "thumb_media_id": thumb_id,
            "need_open_comment": 1,
            "only_fans_can_comment": 0,
        }]
    }
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    try:
        resp = _urlopen(url, data=data)
        result = json.loads(resp.read())
        if "media_id" in result:
            return result["media_id"]
        warn(f"草稿失败: {result}")
    except Exception as e:
        warn(f"草稿异常: {e}")
    return None

# ── HTML 渲染 ─────────────────────────────────────────────────────

def download_img(url, index, cache_dir):
    """下载图片到缓存目录，返回本地路径。"""
    try:
        resp = _urlopen(url)
        data = resp.read()
        ct = resp.headers.get("Content-Type", "")
        ext = ".jpg"
        if "png" in ct: ext = ".png"
        elif "webp" in ct: ext = ".webp"
        path = cache_dir / f"art_img_{index:02d}{ext}"
        with open(path, "wb") as f:
            f.write(data)
        return str(path)
    except Exception:
        return None

def _render_text_block(text):
    """Render a text paragraph with color highlights.
       **bold** = blue, ==text== = orange, ~~text~~ = purple"""
    # Color syntax: ~~purple~~, ==orange==, **blue**
    text = re.sub(r'\~\~(.+?)\~\~', r'<span style="color:#7c3aed;font-weight:600;">\1</span>', text)
    text = re.sub(r'\=\=(.+?)\=\=', r'<span style="color:#d97706;font-weight:600;">\1</span>', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'<span style="color:#2563eb;font-weight:600;">\1</span>', text)
    text = text.replace('\n', '<br>')
    style = (
        f'font-size:15px;color:{TEXT_BODY};line-height:1.75;'
        f'margin:0 0 14px;letter-spacing:0.5px;word-break:break-word;'
    )
    return f'<p style="{style}">{text}</p>'

def _render_comparison_block(text):
    """Render ❌ ✅ comparison blocks."""
    lines = text.strip().split('\n')
    parts = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('❌') or line.startswith('✗'):
            content = line[1:].strip()
            parts.append(
                f'<div style="padding:10px 14px;margin:4px 0;'
                f'background:#fef2f2;border-left:3px solid {ACCENT_RED};'
                f'border-radius:4px;">'
                f'<span style="color:{ACCENT_RED};font-weight:600;margin-right:6px;">✗</span>'
                f'<span style="font-size:15px;color:{TEXT_BODY};">{h(content)}</span></div>'
            )
        elif line.startswith('✅') or line.startswith('✓'):
            content = line[1:].strip()
            parts.append(
                f'<div style="padding:10px 14px;margin:4px 0;'
                f'background:#f0fdf4;border-left:3px solid {ACCENT_GREEN};'
                f'border-radius:4px;">'
                f'<span style="color:{ACCENT_GREEN};font-weight:600;margin-right:6px;">✓</span>'
                f'<span style="font-size:15px;color:{TEXT_BODY};">{h(content)}</span></div>'
            )
        else:
            parts.append(_render_text_block(line))
    return '\n'.join(parts)

def _render_list_block(text):
    """Render bullet list."""
    lines = text.strip().split('\n')
    items = []
    for line in lines:
        line = line.strip()
        if line:
            clean = re.sub(r'^[•·\-*\d+\.\s]+', '', line).strip()
            if clean:
                items.append(clean)
    if not items:
        return ''
    lis = '\n'.join(
        f'<li style="margin:6px 0;font-size:15px;color:{TEXT_BODY};line-height:1.6;">{h(item)}</li>'
        for item in items
    )
    return f'<ul style="padding-left:20px;margin:10px 0 16px;list-style-type:disc;">{lis}</ul>'

def _render_card(icon, title, content, bg_color, border_color, text_color=None):
    """Render a callout card with icon header."""
    inner = (
        f'<div style="padding:16px 18px;">'
        f'<div style="font-size:15px;font-weight:600;margin-bottom:8px;'
        f'color:{text_color or TEXT_BODY};">{icon} {title}</div>'
        f'<div style="font-size:14px;color:{TEXT_DESC};line-height:1.7;">{content}</div>'
        f'</div>'
    )
    return (
        f'<div style="margin:16px 0;border-radius:10px;overflow:hidden;'
        f'background:{bg_color};border:1px solid {border_color};">{inner}</div>'
    )

def build_article_html(article_data, wx_image_urls):
    """生成公众号文章 HTML，支持丰富排版类型。"""
    has_images = bool(wx_image_urls)
    img_idx = 0
    parts = []
    section_count = 0

    def _insert_image():
        nonlocal img_idx
        if has_images and img_idx < len(wx_image_urls):
            url = wx_image_urls[img_idx]
            img_idx += 1
            return (
                f'<img src="{h(url)}" alt="illustration" '
                f'style="width:100%;max-width:100%;display:block;margin:20px 0;" />'
            )
        return ''

    # Cover image (first image as hero)
    if has_images and wx_image_urls:
        parts.append(
            f'<img src="{h(wx_image_urls[0])}" alt="cover" '
            f'style="width:100%;max-width:100%;display:block;margin:0 0 22px;" />'
        )
        img_idx = 1

    # Digest box
    if article_data.get("digest"):
        parts.append(
            f'<div style="margin:0 0 24px;padding:14px 18px;'
            f'background:linear-gradient(135deg,{HIGHLIGHT_BG},#fafcff);border-radius:10px;'
            f'border-left:4px solid {ACCENT};">'
            f'<p style="margin:0;font-size:14px;color:{TEXT_DESC};'
            f'line-height:1.7;">{h(article_data["digest"])}</p></div>'
        )

    # Auto-image emoji map
    emoji_map = {
        "英英释义": "📖", "中英释义": "🌏", "用法辨析": "🔍",
        "职场场景": "💼", "生活场景": "🏠", "常见搭配": "🔗",
        "小测试": "📝", "风险与挑战": "⚠️", "启示": "💡",
    }

    for sec in article_data["sections"]:
        t = sec.get("type", "text")
        c = sec.get("content", "")
        section_count += 1

        if t == "heading":
            emoji = "📌"
            for k, v in emoji_map.items():
                if k in c:
                    emoji = v
                    break
            parts.append(
                f'<div style="margin:28px 0 14px;padding:0 0 0 14px;'
                f'border-left:4px solid {ACCENT};">'
                f'<h2 style="font-size:18px;color:{TEXT_BODY};font-weight:700;'
                f'margin:0;line-height:1.5;">{emoji} {h(c)}</h2></div>'
            )
            if section_count > 1:
                parts.append(_insert_image())

        elif t == "subheading":
            parts.append(
                f'<div style="margin:18px 0 10px;display:inline-block;'
                f'padding:4px 14px;background:{HIGHLIGHT_BG};border-radius:20px;">'
                f'<span style="font-size:14px;color:{ACCENT};font-weight:500;">{h(c)}</span></div>'
            )

        elif t == "text":
            if section_count > 2 and section_count % 4 == 0:
                parts.append(_insert_image())
            parts.append(_render_text_block(c))

        elif t == "comparison":
            parts.append(_render_comparison_block(c))

        elif t == "collocation":
            def _colorize(s):
                s = re.sub(r'\~\~(.+?)\~\~', r'<span style="color:#7c3aed;font-weight:600;">\1</span>', s)
                s = re.sub(r'\=\=(.+?)\=\=', r'<span style="color:#d97706;font-weight:600;">\1</span>', s)
                s = re.sub(r'\*\*(.+?)\*\*', r'<span style="color:#2563eb;font-weight:600;">\1</span>', s)
                return s
            items_raw = c.strip().split('\n\n')
            cards = []
            for item in items_raw:
                lines = item.strip().split('\n')
                if not lines:
                    continue
                phrase = lines[0]
                meaning = ""
                example = ""
                for line in lines[1:]:
                    line = line.strip()
                    if line.startswith('·') or line.startswith('→'):
                        example = line
                    elif line.startswith('「') or line.startswith('（'):
                        meaning = line
                    else:
                        example = line
                card = f'<div style="margin:10px 0;padding:14px 16px;background:#f8fafc;border-radius:8px;border:1px solid {BORDER};">'
                card += f'<div style="font-size:15px;font-weight:600;color:{ACCENT};">{_colorize(phrase)}</div>'
                if meaning:
                    card += f'<div style="font-size:13px;color:{TEXT_DESC};margin-top:4px;">{h(meaning)}</div>'
                if example:
                    card += f'<div style="font-size:14px;color:{TEXT_BODY};margin-top:6px;line-height:1.5;">{_colorize(example)}</div>'
                card += '</div>'
                cards.append(card)
            parts.append(f'<div style="margin:12px 0;">{"".join(cards)}</div>')

        elif t == "tip":
            parts.append(_render_card(
                "💡", "TIPS", c.replace('\n', '<br>'),
                "#f0fdf4", ACCENT_GREEN, ACCENT_GREEN
            ))

        elif t == "warning":
            parts.append(_render_card(
                "⚠️", "注意", c.replace('\n', '<br>'),
                "#fffbeb", ACCENT_ORANGE, ACCENT_ORANGE
            ))

        elif t == "quote":
            parts.append(
                f'<div style="margin:16px 0;padding:14px 18px;'
                f'background:#f9fafb;border-left:4px solid {BORDER};'
                f'border-radius:4px;">'
                f'<p style="margin:0;font-size:15px;color:{TEXT_DESC};'
                f'font-style:italic;line-height:1.7;">"{h(c)}"</p></div>'
            )

        elif t == "quiz":
            content_html = c.replace('\n', '<br>')
            parts.append(
                f'<div style="margin:20px 0;padding:18px;'
                f'background:linear-gradient(135deg,#f5f3ff,#ede9fe);'
                f'border-radius:12px;border:1px solid #ddd6fe;">'
                f'<div style="font-size:15px;font-weight:700;color:{ACCENT_PURPLE};'
                f'margin-bottom:10px;">📝 小测试</div>'
                f'<div style="font-size:15px;color:{TEXT_BODY};line-height:1.8;">{content_html}</div>'
                f'<div style="margin-top:14px;padding:10px 14px;'
                f'background:rgba(124,58,237,0.1);border-radius:8px;text-align:center;">'
                f'<span style="font-size:13px;color:{ACCENT_PURPLE};">🔒 答案下期公布</span></div>'
                f'</div>'
            )

        elif t == "image":
            parts.append(_insert_image())

        elif t == "handwrite":
            parts.append(_insert_image())

        elif t == "divider":
            parts.append(
                f'<div style="margin:24px 0;text-align:center;'
                f'font-size:14px;color:{BORDER};">{h(c) or "✦ ✦ ✦"}</div>'
            )

    # Footer
    sd = article_data.get("source_declaration", "")
    if sd:
        parts.append(
            f'<div style="margin:28px 0 0;padding:16px 18px;'
            f'background:#f9fafb;border-radius:10px;">'
            f'<p style="margin:0;font-size:12px;color:{TEXT_DESC};line-height:1.6;">'
            f'📎 {h(sd)}</p></div>'
        )

    title = article_data.get("title", "")
    series_tag = "📬 简报"
    if "英语笔记" in title:
        series_tag = "📖 英语笔记"
    elif "深度" in title or "分析" in title:
        series_tag = "🔬 深度分析"

    parts.append(
        f'<div style="margin:20px 0 0;padding:16px 0 0;'
        f'border-top:1px solid {BORDER};text-align:center;">'
        f'<span style="font-size:11px;color:#bbb;">{series_tag} · '
        f'内容仅供参考</span></div>'
    )

    body = "\n".join(parts)

    return (
        f'<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n'
        f'<meta charset="UTF-8">\n'
        f'<meta name="viewport" content="width=device-width, initial-scale=1.0, '
        f'maximum-scale=1.0, user-scalable=no">\n'
        f'<title>{h(article_data["title"])}</title>\n</head>\n'
        f'<body style="margin:0;padding:0;background-color:{PAGE_BG};'
        f'font-family:-apple-system,BlinkMacSystemFont,'
        f'\'Helvetica Neue\',\'PingFang SC\',\'Microsoft YaHei\',sans-serif;">\n'
        f'<div style="max-width:640px;margin:0 auto;padding:16px 18px;'
        f'background-color:{ARTICLE_BG};min-height:100vh;">\n{body}\n'
        f'</div>\n</body>\n</html>'
    )

# ── 主入口 ─────────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("用法: python3 publish_article.py <article.json>", file=sys.stderr)
        sys.exit(1)

    article_path = Path(sys.argv[1])
    if not article_path.exists():
        print(f"❌ 找不到文章文件: {article_path}", file=sys.stderr)
        sys.exit(1)

    with open(article_path, "r", encoding="utf-8") as f:
        article_data = json.load(f)

    # 自动补充配图
    article_data = auto_supplement_images(article_data)

    print(f"\n📰 发布公众号文章", file=sys.stderr)
    log(f"标题: {article_data['title'][:50]}...")

    # 保存来源链接到同目录下的 .md 文件
    sources_md = f"# 素材来源 — {article_data['title']}\n\n"
    sources_md += f"**事件日期**：{article_data.get('event_date', article_data['date'])}\n\n"
    sources_md += "| 来源 | URL |\n|------|-----|\n"
    for link in article_data.get("source_links", []):
        sources_md += f"| {link['source']} | {link['url']} |\n"
    sources_md += f"\n_生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}_\n"
    sources_path = article_path.with_suffix(".sources.md")
    with open(sources_path, "w", encoding="utf-8") as f:
        f.write(sources_md)
    log(f"来源: {sources_path.name}")

    # 读取凭据
    if not CONFIG_FILE.exists():
        print("❌ 未配置公众号凭据。请先运行 python3 scripts/wechat_article.py --setup", file=sys.stderr)
        sys.exit(1)
    with open(CONFIG_FILE) as f:
        cfg = json.load(f)

    token = get_token(cfg)
    if not token:
        sys.exit(1)

    # 下载并上传配图
    cache_dir = SKILL_DIR / "scripts" / ".img_cache" / f"article_{article_data['date']}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    # 生成文字卡片封面图
    card_path = None
    full_title = article_data.get("title", "")
    card_main = ""
    card_sub = ""
    if "｜" in full_title:
        parts = full_title.split("｜")
        card_sub = parts[0].strip()
        rest = parts[1].strip()
        # 取 "·" 之前的英文核心词（跳过 I/a/an 等短词）
        before_dot = rest.split("·")[0].strip() if "·" in rest else rest
        words = re.findall(r'[a-zA-Z]+', before_dot)
        meaningful = [w for w in words if len(w) > 2]
        card_main = meaningful[0] if meaningful else (words[0] if words else before_dot[:30])
    if not card_main:
        card_main = full_title[:30]
    card_path = generate_title_card(card_main, card_sub, str(cache_dir / "_title_card.png"))
    if card_path:
        article_data.setdefault("image_sources", []).insert(0, card_path)
        log("生成文字卡片封面")

    # 生成手写风例句卡片
    hw_index = 0
    for sec in article_data.get("sections", []):
        if sec.get("type") == "handwrite":
            hw_index += 1
            text = sec.get("content", "")
            # Parse: first line before === is English, after is Chinese subtitle
            subtitle = ""
            main_text = text
            if "===" in text:
                parts = text.split("===", 1)
                main_text = parts[0].strip()
                subtitle = parts[1].strip()
            card_local = generate_handwrite_card(main_text, subtitle, hw_index, cache_dir)
            if card_local:
                article_data.setdefault("image_sources", []).append(card_local)
                sec["_handwrite_path"] = card_local
                log(f"生成手写卡片 #{hw_index}")

    # 从原文源抓取 og:image 补充配图（仅非英语笔记类文章）
    title = article_data.get("title", "")
    if "英语笔记" not in title:
        fetch_og_images_from_sources(article_data)
        log("从原文源抓取 og:image")
    else:
        log("英语笔记类文章：跳过 og:image 自动抓取")

    # 确保标题卡片始终在第一位
    if card_path:
        try:
            article_data["image_sources"].remove(card_path)
        except ValueError:
            pass
        article_data["image_sources"].insert(0, card_path)

    step("上传配图到微信 CDN...")
    wx_urls = []
    for i, img_src in enumerate(article_data.get("image_sources", [])):
        log(f"[{i+1}/{len(article_data.get('image_sources', []))}] 下载并上传...")
        # Handle local file paths (title card, handwrite cards)
        local = None
        if isinstance(img_src, str) and os.path.exists(img_src):
            local = img_src
        else:
            local = download_img(img_src, i + 1, cache_dir)
        if local:
            wx_url = upload_img(local, token)
            if wx_url:
                wx_urls.append(wx_url)

    # 封面图：直接使用标题卡片
    step("上传封面图...")
    thumb_id = None
    if card_path and os.path.exists(card_path):
        thumb_id = upload_material(card_path, token)
        log("封面图使用标题卡片")
    elif wx_urls:
        # 兜底：用第一张已上传图片
        first_local = cache_dir / "art_img_01.jpg"
        if first_local.exists():
            thumb_id = upload_material(str(first_local), token)
        elif cache_dir.exists():
            for f in sorted(cache_dir.iterdir()):
                if f.is_file():
                    thumb_id = upload_material(str(f), token)
                    break

    # 生成 HTML
    step("生成文章 HTML...")
    html = build_article_html(article_data, wx_urls)

    # 保存本地副本
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    date_str = article_data["date"]
    safe_title = re.sub(r'[^\w\u4e00-\u9fff]', '_', article_data["title"])[:20]
    out = OUTPUT_DIR / f"article_{date_str}_{safe_title}.html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    log(f"本地备份: {out}")

    # 创建草稿
    step("创建公众号草稿...")
    mid = create_draft(
        title=article_data["title"],
        html=html,
        author=article_data.get("author", "简报"),
        digest=article_data.get("digest", ""),
        thumb_id=thumb_id or "",
        token=token,
    )

    if mid:
        print(f"\n  ✅ 文章发布成功！", file=sys.stderr)
        print(f"    标题: {article_data['title']}", file=sys.stderr)
        print(f"    图片: {len(wx_urls)} 张", file=sys.stderr)
        print(f"    media_id: {mid}", file=sys.stderr)
        print(f"    查看: mp.weixin.qq.com → 草稿箱", file=sys.stderr)
    else:
        print(f"\n  ❌ 发布失败", file=sys.stderr)
        print(f"     本地 HTML 已保存: {out}", file=sys.stderr)

if __name__ == "__main__":
    main()
